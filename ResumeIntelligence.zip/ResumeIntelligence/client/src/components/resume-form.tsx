import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { ResumeData, resumeDataSchema } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  User, 
  FileText, 
  Briefcase, 
  GraduationCap, 
  Settings, 
  Award, 
  Plus, 
  Trash2, 
  X, 
  CheckCircle, 
  Save, 
  Eye 
} from "lucide-react";

interface ResumeFormProps {
  initialData: ResumeData;
  onSubmit: (data: ResumeData) => void;
  isSubmitting: boolean;
}

export default function ResumeForm({ initialData, onSubmit, isSubmitting }: ResumeFormProps) {
  const [technicalSkills, setTechnicalSkills] = useState<string[]>(initialData.skills.technical);
  const [softSkills, setSoftSkills] = useState<string[]>(initialData.skills.soft);
  const [newTechnicalSkill, setNewTechnicalSkill] = useState("");
  const [newSoftSkill, setNewSoftSkill] = useState("");

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm<ResumeData>({
    resolver: zodResolver(resumeDataSchema),
    defaultValues: initialData,
  });

  const workExperience = watch("workExperience");
  const education = watch("education");
  const certifications = watch("certifications");

  const addTechnicalSkill = () => {
    if (newTechnicalSkill.trim()) {
      setTechnicalSkills([...technicalSkills, newTechnicalSkill.trim()]);
      setNewTechnicalSkill("");
    }
  };

  const addSoftSkill = () => {
    if (newSoftSkill.trim()) {
      setSoftSkills([...softSkills, newSoftSkill.trim()]);
      setNewSoftSkill("");
    }
  };

  const removeTechnicalSkill = (index: number) => {
    setTechnicalSkills(technicalSkills.filter((_, i) => i !== index));
  };

  const removeSoftSkill = (index: number) => {
    setSoftSkills(softSkills.filter((_, i) => i !== index));
  };

  const addWorkExperience = () => {
    setValue("workExperience", [...workExperience, {
      jobTitle: "",
      company: "",
      startDate: "",
      endDate: "",
      description: "",
    }]);
  };

  const removeWorkExperience = (index: number) => {
    setValue("workExperience", workExperience.filter((_, i) => i !== index));
  };

  const addEducation = () => {
    setValue("education", [...education, {
      degree: "",
      institution: "",
      graduationYear: new Date().getFullYear(),
      gpa: "",
    }]);
  };

  const removeEducation = (index: number) => {
    setValue("education", education.filter((_, i) => i !== index));
  };

  const addCertification = () => {
    setValue("certifications", [...certifications, {
      name: "",
      issuer: "",
      issueDate: "",
      expirationDate: "",
    }]);
  };

  const removeCertification = (index: number) => {
    setValue("certifications", certifications.filter((_, i) => i !== index));
  };

  const onFormSubmit = (data: ResumeData) => {
    const formData = {
      ...data,
      skills: {
        technical: technicalSkills,
        soft: softSkills,
      },
    };
    onSubmit(formData);
  };

  return (
    <Card className="bg-white shadow-sm border border-gray-200">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-semibold text-gray-900">Review Your Information</h2>
            <p className="text-gray-600">AI has extracted the following information. Please review and edit as needed.</p>
          </div>
          <div className="flex items-center space-x-2 text-sm text-green-600">
            <CheckCircle className="h-4 w-4" />
            <span>Parsing Complete</span>
          </div>
        </div>

        <form onSubmit={handleSubmit(onFormSubmit)} className="space-y-8">
          {/* Personal Information */}
          <div className="border-b border-gray-200 pb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <User className="text-blue-600 mr-2 h-5 w-5" />
              Personal Information
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="fullName">Full Name *</Label>
                <Input
                  id="fullName"
                  {...register("personalInfo.fullName")}
                  className="mt-1"
                />
                {errors.personalInfo?.fullName && (
                  <p className="text-sm text-red-600 mt-1">{errors.personalInfo.fullName.message}</p>
                )}
              </div>
              <div>
                <Label htmlFor="email">Email Address *</Label>
                <Input
                  id="email"
                  type="email"
                  {...register("personalInfo.email")}
                  className="mt-1"
                />
                {errors.personalInfo?.email && (
                  <p className="text-sm text-red-600 mt-1">{errors.personalInfo.email.message}</p>
                )}
              </div>
              <div>
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  {...register("personalInfo.phone")}
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="location">Location</Label>
                <Input
                  id="location"
                  {...register("personalInfo.location")}
                  className="mt-1"
                />
              </div>
              <div className="md:col-span-2">
                <Label htmlFor="linkedin">LinkedIn Profile</Label>
                <Input
                  id="linkedin"
                  type="url"
                  {...register("personalInfo.linkedin")}
                  className="mt-1"
                />
              </div>
            </div>
          </div>

          {/* Professional Summary */}
          <div className="border-b border-gray-200 pb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <FileText className="text-blue-600 mr-2 h-5 w-5" />
              Professional Summary
            </h3>
            <div>
              <Label htmlFor="summary">Summary</Label>
              <Textarea
                id="summary"
                {...register("summary")}
                rows={4}
                className="mt-1"
              />
            </div>
          </div>

          {/* Work Experience */}
          <div className="border-b border-gray-200 pb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <Briefcase className="text-blue-600 mr-2 h-5 w-5" />
              Work Experience
            </h3>
            <div className="space-y-6">
              {workExperience.map((_, index) => (
                <div key={index} className="bg-gray-50 rounded-lg p-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <Label htmlFor={`jobTitle-${index}`}>Job Title</Label>
                      <Input
                        id={`jobTitle-${index}`}
                        {...register(`workExperience.${index}.jobTitle` as const)}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor={`company-${index}`}>Company</Label>
                      <Input
                        id={`company-${index}`}
                        {...register(`workExperience.${index}.company` as const)}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor={`startDate-${index}`}>Start Date</Label>
                      <Input
                        id={`startDate-${index}`}
                        type="date"
                        {...register(`workExperience.${index}.startDate` as const)}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor={`endDate-${index}`}>End Date</Label>
                      <Input
                        id={`endDate-${index}`}
                        type="date"
                        {...register(`workExperience.${index}.endDate` as const)}
                        className="mt-1"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor={`description-${index}`}>Job Description</Label>
                    <Textarea
                      id={`description-${index}`}
                      {...register(`workExperience.${index}.description` as const)}
                      rows={3}
                      className="mt-1"
                    />
                  </div>
                  <Button
                    type="button"
                    variant="destructive"
                    size="sm"
                    onClick={() => removeWorkExperience(index)}
                    className="mt-2"
                  >
                    <Trash2 className="h-4 w-4 mr-1" />
                    Remove Experience
                  </Button>
                </div>
              ))}
            </div>
            <Button
              type="button"
              variant="outline"
              onClick={addWorkExperience}
              className="mt-4"
            >
              <Plus className="h-4 w-4 mr-1" />
              Add Work Experience
            </Button>
          </div>

          {/* Education */}
          <div className="border-b border-gray-200 pb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <GraduationCap className="text-blue-600 mr-2 h-5 w-5" />
              Education
            </h3>
            <div className="space-y-4">
              {education.map((_, index) => (
                <div key={index} className="bg-gray-50 rounded-lg p-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <Label htmlFor={`degree-${index}`}>Degree</Label>
                      <Input
                        id={`degree-${index}`}
                        {...register(`education.${index}.degree` as const)}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor={`institution-${index}`}>Institution</Label>
                      <Input
                        id={`institution-${index}`}
                        {...register(`education.${index}.institution` as const)}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor={`graduationYear-${index}`}>Graduation Year</Label>
                      <Input
                        id={`graduationYear-${index}`}
                        type="number"
                        {...register(`education.${index}.graduationYear` as const, { valueAsNumber: true })}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor={`gpa-${index}`}>GPA (Optional)</Label>
                      <Input
                        id={`gpa-${index}`}
                        {...register(`education.${index}.gpa` as const)}
                        className="mt-1"
                      />
                    </div>
                  </div>
                  <Button
                    type="button"
                    variant="destructive"
                    size="sm"
                    onClick={() => removeEducation(index)}
                  >
                    <Trash2 className="h-4 w-4 mr-1" />
                    Remove Education
                  </Button>
                </div>
              ))}
            </div>
            <Button
              type="button"
              variant="outline"
              onClick={addEducation}
              className="mt-4"
            >
              <Plus className="h-4 w-4 mr-1" />
              Add Education
            </Button>
          </div>

          {/* Skills */}
          <div className="border-b border-gray-200 pb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <Settings className="text-blue-600 mr-2 h-5 w-5" />
              Skills
            </h3>
            <div className="space-y-4">
              <div>
                <Label>Technical Skills</Label>
                <div className="flex flex-wrap gap-2 mb-2 mt-1">
                  {technicalSkills.map((skill, index) => (
                    <Badge key={index} variant="secondary" className="bg-blue-100 text-blue-800">
                      {skill}
                      <button
                        type="button"
                        onClick={() => removeTechnicalSkill(index)}
                        className="ml-2 text-blue-600 hover:text-blue-800"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
                <div className="flex gap-2">
                  <Input
                    value={newTechnicalSkill}
                    onChange={(e) => setNewTechnicalSkill(e.target.value)}
                    placeholder="Add a skill and press Enter"
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addTechnicalSkill())}
                  />
                  <Button type="button" onClick={addTechnicalSkill}>
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              <div>
                <Label>Soft Skills</Label>
                <div className="flex flex-wrap gap-2 mb-2 mt-1">
                  {softSkills.map((skill, index) => (
                    <Badge key={index} variant="secondary" className="bg-green-100 text-green-800">
                      {skill}
                      <button
                        type="button"
                        onClick={() => removeSoftSkill(index)}
                        className="ml-2 text-green-600 hover:text-green-800"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
                <div className="flex gap-2">
                  <Input
                    value={newSoftSkill}
                    onChange={(e) => setNewSoftSkill(e.target.value)}
                    placeholder="Add a soft skill and press Enter"
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addSoftSkill())}
                  />
                  <Button type="button" onClick={addSoftSkill}>
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </div>

          {/* Certifications */}
          <div className="pb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <Award className="text-blue-600 mr-2 h-5 w-5" />
              Certifications
            </h3>
            <div className="space-y-4">
              {certifications.map((_, index) => (
                <div key={index} className="bg-gray-50 rounded-lg p-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <Label htmlFor={`certName-${index}`}>Certification Name</Label>
                      <Input
                        id={`certName-${index}`}
                        {...register(`certifications.${index}.name` as const)}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor={`issuer-${index}`}>Issuing Organization</Label>
                      <Input
                        id={`issuer-${index}`}
                        {...register(`certifications.${index}.issuer` as const)}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor={`issueDate-${index}`}>Issue Date</Label>
                      <Input
                        id={`issueDate-${index}`}
                        type="date"
                        {...register(`certifications.${index}.issueDate` as const)}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor={`expirationDate-${index}`}>Expiration Date</Label>
                      <Input
                        id={`expirationDate-${index}`}
                        type="date"
                        {...register(`certifications.${index}.expirationDate` as const)}
                        className="mt-1"
                      />
                    </div>
                  </div>
                  <Button
                    type="button"
                    variant="destructive"
                    size="sm"
                    onClick={() => removeCertification(index)}
                  >
                    <Trash2 className="h-4 w-4 mr-1" />
                    Remove Certification
                  </Button>
                </div>
              ))}
            </div>
            <Button
              type="button"
              variant="outline"
              onClick={addCertification}
              className="mt-4"
            >
              <Plus className="h-4 w-4 mr-1" />
              Add Certification
            </Button>
          </div>

          {/* Form Actions */}
          <div className="flex flex-col sm:flex-row gap-4 pt-6 border-t border-gray-200">
            <Button
              type="button"
              variant="outline"
              className="flex-1"
            >
              <Eye className="h-4 w-4 mr-2" />
              Preview Resume
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Save Resume
                </>
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
