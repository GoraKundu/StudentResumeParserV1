import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { ResumeData } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import Header from "@/components/header";
import FileUpload from "@/components/file-upload";
import ProcessingState from "@/components/processing-state";
import ResumeForm from "@/components/resume-form";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle, AlertCircle, Eye, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";

type AppStep = "upload" | "processing" | "form" | "success" | "error";

interface UploadResponse {
  success: boolean;
  resumeId: number;
  parsedData: ResumeData;
}

interface UpdateResponse {
  success: boolean;
  resume: any;
}

export default function Home() {
  const [currentStep, setCurrentStep] = useState<AppStep>("upload");
  const [resumeId, setResumeId] = useState<number | null>(null);
  const [parsedData, setParsedData] = useState<ResumeData | null>(null);
  const [errorMessage, setErrorMessage] = useState<string>("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("resume", file);
      
      const response = await fetch("/api/resumes/upload", {
        method: "POST",
        body: formData,
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Upload failed");
      }
      
      return response.json() as Promise<UploadResponse>;
    },
    onSuccess: (data) => {
      setResumeId(data.resumeId);
      setParsedData(data.parsedData);
      setCurrentStep("form");
      toast({
        title: "Resume processed successfully!",
        description: "Review and edit the extracted information below.",
      });
    },
    onError: (error) => {
      setErrorMessage(error.message);
      setCurrentStep("error");
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data: ResumeData) => {
      if (!resumeId) throw new Error("No resume ID");
      
      const response = await apiRequest("PUT", `/api/resumes/${resumeId}`, data);
      return response.json() as Promise<UpdateResponse>;
    },
    onSuccess: () => {
      setCurrentStep("success");
      queryClient.invalidateQueries({ queryKey: ['/api/resumes', resumeId] });
      toast({
        title: "Resume saved successfully!",
        description: "Your resume has been saved to your profile.",
      });
    },
    onError: (error) => {
      toast({
        title: "Save failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleFileUpload = (file: File) => {
    setCurrentStep("processing");
    uploadMutation.mutate(file);
  };

  const handleFormSubmit = (data: ResumeData) => {
    updateMutation.mutate(data);
  };

  const handleStartOver = () => {
    setCurrentStep("upload");
    setResumeId(null);
    setParsedData(null);
    setErrorMessage("");
  };

  const renderProgressSteps = () => {
    const steps = [
      { key: "upload", label: "Upload Resume", icon: "upload" },
      { key: "processing", label: "AI Processing", icon: "cog" },
      { key: "form", label: "Review & Edit", icon: "edit" },
      { key: "success", label: "Complete", icon: "check" },
    ];

    const stepOrder = ["upload", "processing", "form", "success"];
    const currentIndex = stepOrder.indexOf(currentStep);

    return (
      <div className="mb-8">
        <div className="flex items-center justify-between max-w-2xl mx-auto">
          {steps.map((step, index) => {
            const isActive = index <= currentIndex;
            const isCurrent = index === currentIndex;
            
            return (
              <div key={step.key} className="flex items-center">
                <div className="flex items-center space-x-2">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      isActive
                        ? "bg-blue-600 text-white"
                        : "bg-gray-300 text-gray-500"
                    }`}
                  >
                    {step.icon === "upload" && <i className="fas fa-upload text-sm" />}
                    {step.icon === "cog" && <i className="fas fa-cog text-sm" />}
                    {step.icon === "edit" && <i className="fas fa-edit text-sm" />}
                    {step.icon === "check" && <i className="fas fa-check text-sm" />}
                  </div>
                  <span
                    className={`text-sm font-medium ${
                      isActive ? "text-blue-600" : "text-gray-500"
                    }`}
                  >
                    {step.label}
                  </span>
                </div>
                {index < steps.length - 1 && (
                  <div className="w-12 h-px bg-gray-300 mx-4" />
                )}
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const renderContent = () => {
    switch (currentStep) {
      case "upload":
        return <FileUpload onUpload={handleFileUpload} />;
      
      case "processing":
        return <ProcessingState />;
      
      case "form":
        return parsedData ? (
          <ResumeForm
            initialData={parsedData}
            onSubmit={handleFormSubmit}
            isSubmitting={updateMutation.isPending}
          />
        ) : null;
      
      case "success":
        return (
          <Card className="max-w-2xl mx-auto">
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold text-green-800 mb-2">
                  Resume Saved Successfully!
                </h3>
                <p className="text-green-700 mb-6">
                  Your resume has been processed and saved to your profile.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button className="bg-green-600 hover:bg-green-700">
                    <Eye className="h-4 w-4 mr-2" />
                    View Resume
                  </Button>
                  <Button variant="outline" onClick={handleStartOver}>
                    <Plus className="h-4 w-4 mr-2" />
                    Upload Another Resume
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      
      case "error":
        return (
          <Card className="max-w-2xl mx-auto border-red-200 bg-red-50">
            <CardContent className="pt-6">
              <div className="flex items-start space-x-3">
                <AlertCircle className="h-6 w-6 text-red-500 mt-1" />
                <div>
                  <h3 className="text-lg font-semibold text-red-800 mb-2">
                    Processing Error
                  </h3>
                  <p className="text-red-700 mb-4">{errorMessage}</p>
                  <div className="flex space-x-3">
                    <Button 
                      onClick={handleStartOver}
                      className="bg-red-600 hover:bg-red-700"
                    >
                      Try Again
                    </Button>
                    <Button variant="outline" onClick={handleStartOver}>
                      Upload Different File
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderProgressSteps()}
        {renderContent()}
      </main>
    </div>
  );
}
