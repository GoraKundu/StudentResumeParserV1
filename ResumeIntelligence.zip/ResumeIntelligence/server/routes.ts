import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { resumeDataSchema } from "@shared/schema";
import { z } from "zod";
import multer from "multer";
import { parseResume } from "./services/fileParser";
import { extractResumeData } from "./services/openai";

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ];
    
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only PDF, DOC, and DOCX files are allowed.'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Upload and parse resume
  app.post("/api/resumes/upload", upload.single('resume'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const { originalname: fileName, mimetype: fileType, size: fileSize, buffer } = req.file;

      // Parse file content
      const textContent = await parseResume(buffer, fileType);
      
      // Extract structured data using OpenAI
      const parsedData = await extractResumeData(textContent);

      // Save to database
      const resume = await storage.createResume({
        userId: null, // For now, not requiring authentication
        fileName,
        fileType,
        fileSize,
        originalContent: textContent,
        parsedData,
      });

      res.json({ 
        success: true, 
        resumeId: resume.id,
        parsedData: resume.parsedData
      });
    } catch (error) {
      console.error("Resume upload error:", error);
      res.status(500).json({ 
        error: "Failed to process resume", 
        details: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Update resume data
  app.put("/api/resumes/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const resumeId = parseInt(id);
      
      if (isNaN(resumeId)) {
        return res.status(400).json({ error: "Invalid resume ID" });
      }

      // Validate the resume data
      const validatedData = resumeDataSchema.parse(req.body);

      // Update the resume
      const updatedResume = await storage.updateResume(resumeId, {
        parsedData: validatedData
      });

      res.json({ 
        success: true, 
        resume: updatedResume 
      });
    } catch (error) {
      console.error("Resume update error:", error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          error: "Invalid data format", 
          details: error.errors 
        });
      }
      
      res.status(500).json({ 
        error: "Failed to update resume", 
        details: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Get resume by ID
  app.get("/api/resumes/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const resumeId = parseInt(id);
      
      if (isNaN(resumeId)) {
        return res.status(400).json({ error: "Invalid resume ID" });
      }

      const resume = await storage.getResume(resumeId);
      
      if (!resume) {
        return res.status(404).json({ error: "Resume not found" });
      }

      res.json({ resume });
    } catch (error) {
      console.error("Get resume error:", error);
      res.status(500).json({ 
        error: "Failed to fetch resume", 
        details: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
