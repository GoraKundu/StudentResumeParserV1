import OpenAI from "openai";
import { ResumeData } from "@shared/schema";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.VITE_OPENAI_API_KEY || ""
});

export async function extractResumeData(textContent: string): Promise<ResumeData> {
  try {
    const prompt = `
You are an expert resume parser. Extract structured information from the following resume text and return it as JSON.

Please extract the following information:
1. Personal Information (full name, email, phone, location, LinkedIn profile)
2. Professional Summary
3. Work Experience (job title, company, start date, end date, description)
4. Education (degree, institution, graduation year, GPA if mentioned)
5. Skills (separate technical and soft skills)
6. Certifications (name, issuing organization, issue date, expiration date)

For dates, use YYYY-MM-DD format when possible, or YYYY format for years only.
For work experience that is current, leave endDate empty.
Extract skills as arrays of strings.
If information is not available, use empty strings or empty arrays as appropriate.

Return the data in this exact JSON structure:
{
  "personalInfo": {
    "fullName": "string",
    "email": "string",
    "phone": "string",
    "location": "string",
    "linkedin": "string"
  },
  "summary": "string",
  "workExperience": [
    {
      "jobTitle": "string",
      "company": "string",
      "startDate": "string",
      "endDate": "string",
      "description": "string"
    }
  ],
  "education": [
    {
      "degree": "string",
      "institution": "string",
      "graduationYear": number,
      "gpa": "string"
    }
  ],
  "skills": {
    "technical": ["string"],
    "soft": ["string"]
  },
  "certifications": [
    {
      "name": "string",
      "issuer": "string",
      "issueDate": "string",
      "expirationDate": "string"
    }
  ]
}

Resume text:
${textContent}
`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert resume parser. Extract structured information from resumes and return valid JSON."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.1,
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No content received from OpenAI");
    }

    const parsedData = JSON.parse(content);
    
    // Validate the parsed data structure
    const validatedData = {
      personalInfo: {
        fullName: parsedData.personalInfo?.fullName || "",
        email: parsedData.personalInfo?.email || "",
        phone: parsedData.personalInfo?.phone || "",
        location: parsedData.personalInfo?.location || "",
        linkedin: parsedData.personalInfo?.linkedin || "",
      },
      summary: parsedData.summary || "",
      workExperience: Array.isArray(parsedData.workExperience) 
        ? parsedData.workExperience.map((exp: any) => ({
            jobTitle: exp.jobTitle || "",
            company: exp.company || "",
            startDate: exp.startDate || "",
            endDate: exp.endDate || "",
            description: exp.description || "",
          }))
        : [],
      education: Array.isArray(parsedData.education) 
        ? parsedData.education.map((edu: any) => ({
            degree: edu.degree || "",
            institution: edu.institution || "",
            graduationYear: parseInt(edu.graduationYear) || new Date().getFullYear(),
            gpa: edu.gpa || "",
          }))
        : [],
      skills: {
        technical: Array.isArray(parsedData.skills?.technical) ? parsedData.skills.technical : [],
        soft: Array.isArray(parsedData.skills?.soft) ? parsedData.skills.soft : [],
      },
      certifications: Array.isArray(parsedData.certifications) 
        ? parsedData.certifications.map((cert: any) => ({
            name: cert.name || "",
            issuer: cert.issuer || "",
            issueDate: cert.issueDate || "",
            expirationDate: cert.expirationDate || "",
          }))
        : [],
    };

    return validatedData;
  } catch (error) {
    console.error("OpenAI extraction error:", error);
    throw new Error(`Failed to extract resume data: ${error instanceof Error ? error.message : "Unknown error"}`);
  }
}
