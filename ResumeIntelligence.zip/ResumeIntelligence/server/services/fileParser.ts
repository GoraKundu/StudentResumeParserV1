import pdfParse from "pdf-parse";

export async function parseResume(buffer: Buffer, mimeType: string): Promise<string> {
  try {
    switch (mimeType) {
      case 'application/pdf':
        return await parsePDF(buffer);
      case 'application/msword':
      case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
        return await parseDocx(buffer);
      default:
        throw new Error(`Unsupported file type: ${mimeType}`);
    }
  } catch (error) {
    console.error("File parsing error:", error);
    throw new Error(`Failed to parse file: ${error instanceof Error ? error.message : "Unknown error"}`);
  }
}

async function parsePDF(buffer: Buffer): Promise<string> {
  const data = await pdfParse(buffer);
  return data.text;
}

async function parseDocx(buffer: Buffer): Promise<string> {
  // For DOC/DOCX files, we'll use a simplified approach
  // In a production app, you'd want to use a proper library like mammoth.js
  // For now, we'll convert the buffer to string and clean it up
  try {
    const text = buffer.toString('utf8');
    // Remove binary data and clean up the text
    const cleanText = text
      .replace(/[^\x20-\x7E\n\r\t]/g, ' ') // Remove non-printable characters
      .replace(/\s+/g, ' ') // Replace multiple spaces with single space
      .trim();
    
    if (cleanText.length < 50) {
      throw new Error("Document appears to be empty or corrupted");
    }
    
    return cleanText;
  } catch (error) {
    throw new Error("Failed to parse Word document. Please try converting to PDF first.");
  }
}
